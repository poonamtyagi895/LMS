import CustomToast from "./CustomToast";

const ToastProvider = () => {
  return <CustomToast />;
};

export default ToastProvider;
