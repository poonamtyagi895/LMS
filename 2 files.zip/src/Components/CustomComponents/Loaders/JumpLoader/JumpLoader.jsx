import "./JumpLoader.css";

const JumpLoader = () => {
  return (
    <div className="jump-loader-wrapper">
      <div className="jump-loader"></div>
    </div>
  );
};

export default JumpLoader;
