import React from "react";
import "./BackGround.css";

const BackGround = () => {
  return (
    <div className="back-ground">
        Back Ground
    </div>
  );
};

export default BackGround;
