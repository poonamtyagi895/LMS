import "./BulletPoint.css";

const BulletPoint = () => {
  return (
    <div className="bullet-point">
      <div className="bullet-point-indicator"></div>
    </div>
  );
};

export default BulletPoint;
