import "./TestManagement.css";

const TestManagement = () => {
  return (
    <div className="test-management">
      <h1>Test Management</h1>
      <p>Manage tests, assignments and evaluations here.</p>
    </div>
  );
};

export default TestManagement;
