/* global TweenMax, Power2, Power4 */
import { useEffect } from "react";
import "./Graph.css";

const X_POSITIONS = [60, 160, 260, 360, 460, 560, 660];
const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function Graph({
  title,
  data,
  maxValue,
  unit = "",
  ySteps = [],
}) {
  useEffect(() => {
    if (!data?.length) return;

    const MAX_HEIGHT = 160;

    const destArray = data.map(
      (v) => (v / maxValue) * MAX_HEIGHT
    );

    const circles = document.querySelectorAll(".graph-dot");
    const lines = document.querySelectorAll(".graph-line");
    const tooltip = document.getElementById("graph-tooltip");

    TweenMax.set(circles, { scale: 0, transformOrigin: "50% 50%" });

    TweenMax.set([...circles, ...lines], { y: "+=160" });

    circles.forEach((circle, i) => {
      TweenMax.to(circle, 1.6, {
        attr: { cy: 260 - destArray[i] },
        delay: i * 0.15,
        scale: 1,
        ease: Power4.easeInOut,
      });

      circle.addEventListener("mouseenter", () => {
        tooltip.innerHTML = `${data[i]}${unit}`;
        tooltip.style.opacity = 1;
      });

      circle.addEventListener("mousemove", (e) => {
        tooltip.style.left = `${e.pageX + 10}px`;
        tooltip.style.top = `${e.pageY - 30}px`;
      });

      circle.addEventListener("mouseleave", () => {
        tooltip.style.opacity = 0;
      });
    });

    lines.forEach((line, i) => {
      if (!circles[i + 1]) return;

      TweenMax.to(line, 1, {
        attr: {
          x1: X_POSITIONS[i],
          y1: 260 - destArray[i],
          x2: X_POSITIONS[i + 1],
          y2: 260 - destArray[i + 1],
        },
        delay: i * 0.15,
        ease: Power4.easeInOut,
      });
    });
  }, [data, maxValue, unit]);

  return (
    <div className="graph-container">
      <h3 className="graph-title">{title}</h3>

      {/* TOOLTIP */}
      <div id="graph-tooltip" className="graph-tooltip" />

      <svg viewBox="0 0 760 300">
        {/* Y AXIS */}
        <line x1="40" y1="40" x2="40" y2="260" stroke="#fff" opacity="0.4" />

        {ySteps.map((v, i) => (
          <g key={i}>
            <line
              x1="36"
              x2="40"
              y1={260 - (v / maxValue) * 160}
              y2={260 - (v / maxValue) * 160}
              stroke="#fff"
            />
            <text
              x="30"
              y={265 - (v / maxValue) * 160}
              fill="#fff"
              fontSize="10"
              textAnchor="end"
            >
              {v}
            </text>
          </g>
        ))}

        {/* X AXIS */}
        <line x1="40" y1="260" x2="720" y2="260" stroke="#fff" opacity="0.4" />

        {/* LINES */}
        {data.slice(0, -1).map((_, i) => (
          <line
            key={i}
            className="graph-line"
            x1={X_POSITIONS[i]}
            y1="260"
            x2={X_POSITIONS[i]}
            y2="260"
            stroke="#ffffff"
            strokeWidth="2"
            strokeLinecap="round"
          />
        ))}

        {/* DOTS */}
        {data.map((_, i) => (
          <circle
            key={i}
            className="graph-dot"
            cx={X_POSITIONS[i]}
            cy="260"
            r="5"
            fill="#6d28d9"
          />
        ))}

        {/* DAY LABELS */}
        {DAYS.map((day, i) => (
          <text
            key={day}
            x={X_POSITIONS[i]}
            y="285"
            fill="#fff"
            fontSize="11"
            textAnchor="middle"
          >
            {day}
          </text>
        ))}
      </svg>
    </div>
  );
}
